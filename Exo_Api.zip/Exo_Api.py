import os
import json
import zipfile
import requests
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

# ==========================
# === QUESTION 1 ===
# ==========================
# Charger la carte des pays et des rivières


try:
    countries = gpd.read_file('World_Countries.shp')
    rivers = gpd.read_file('World_Hydrography.shp')
    print("Fichiers Shapefile chargés avec succès.")
except Exception as e:
    print(f"Erreur lors du chargement : {e}. Vérifie que les fichiers sont bien dans le dossier.")

# ==========================
# === QUESTION 2 ===
# ==========================
# Vérifier et afficher la projection (CRS) des cartes

if 'countries' in locals() and 'rivers' in locals():
    print(f"CRS des pays : {countries.crs}")
    print(f"CRS des rivières : {rivers.crs}")


    if countries.crs != "EPSG:4326":
        countries = countries.to_crs("EPSG:4326")
    if rivers.crs != "EPSG:4326":
        rivers = rivers.to_crs("EPSG:4326")

# ==========================
# === QUESTION 3 ===
# ==========================
# Représenter une carte du monde avec les rivières, légende et titre

if 'countries' in locals() and 'rivers' in locals():
    fig, ax = plt.subplots(figsize=(12, 6))

    # Affichage des couches
    countries.plot(ax=ax, color='lightgrey', edgecolor='white', linewidth=0.5)
    rivers.plot(ax=ax, color='blue', linewidth=1)

    # Création d'une légende
    custom_lines = [
        Patch(facecolor='lightgrey', edgecolor='white', label='Pays'),
        Line2D([0], [0], color='blue', lw=2, label='Rivières')
    ]
    ax.legend(handles=custom_lines, loc='lower left')
    ax.set_title("Carte du monde et principales rivières", fontsize=14)
    ax.axis('off')
    plt.show()

# ==========================
# === QUESTION 4 ===
# ==========================
# Intersection et calcul de la longueur des rivières par pays

if 'countries' in locals() and 'rivers' in locals():
    # Intersection géographique
    rivers_inter = gpd.overlay(rivers, countries, how='intersection')

    # Projection en Pseudo-Mercator (EPSG:3857) pour calculer la longueur en mètres (puis km)
    rivers_inter_proj = rivers_inter.to_crs("EPSG:3857")
    rivers_inter['length_km'] = rivers_inter_proj.geometry.length / 1000

    # Agrégation des longueurs par pays (On cherche NAME)
    col_name = 'NAME' if 'NAME' in countries.columns else countries.columns[0]
    lengths_per_country = rivers_inter.groupby(col_name)['length_km'].sum().reset_index()

    # Jointure avec la carte des pays
    countries_length = countries.merge(lengths_per_country, on=col_name, how='left')
    countries_length['length_km'] = countries_length['length_km'].fillna(0)  # Gérer les pays sans rivière


    fig, ax = plt.subplots(figsize=(12, 6))
    countries_length.plot(column='length_km', ax=ax, cmap='Blues', legend=True,
                          legend_kwds={'label': "Longueur des rivières (km)"})
    ax.set_title("Longueur totale des rivières par pays", fontsize=14)
    ax.axis('off')
    plt.show()

# ==========================
# === QUESTION 5 ===
# ==========================
# Préparation des variables de l'API de l'American Community Survey (ACS) du US Census

API_KEY = "8c2b2d2ecd3e095e1cfdb85a9401303e2f2097d7" 

BASE_URL_ACS = "https://api.census.gov/data/{year}/acs/acs1"

# ==========================
# === QUESTION 6 ===
# ==========================
# Requête API : Population en 2019 par État américain

url_2019 = BASE_URL_ACS.format(year=2019)
# Paramètres : nom de l'état (NAME) et population (B01003_001E)
params_2019 = {
    "get": "NAME,B01003_001E",
    "for": "state:*",
    "key": API_KEY
}

print("\nRécupération des données 2019 via l'API...")
try:
    response = requests.get(url_2019, params=params_2019)
    response.raise_for_status()
    data_2019 = json.loads(response.text)

    # Création du DataFrame : la première ligne contient les en-têtes
    df_2019 = pd.DataFrame(data_2019[1:], columns=data_2019[0])
    df_2019.rename(columns={'B01003_001E': 'POPULATION'}, inplace=True)
    df_2019['POPULATION'] = pd.to_numeric(df_2019['POPULATION'])
    print("Succès de la requête 2019. Aperçu :")
    print(df_2019.head())
except Exception as e:
    print(f"Erreur API (Vérifiez la clé à la ligne 80) : {e}")

# ==========================
# === QUESTION 7 ===
# ==========================
# Programme pour récupérer la population depuis 2011 pour chaque État

years = range(2011, 2020)
all_years_data = []

print("\nRécupération de la population par état depuis 2011...")
for year in years:
    url_year = BASE_URL_ACS.format(year=year)
    params = {"get": "NAME,B01003_001E", "for": "state:*", "key": API_KEY}

    try:
        res = requests.get(url_year, params=params)
        if res.status_code == 200:
            data = json.loads(res.text)
            df_year = pd.DataFrame(data[1:], columns=data[0])
            df_year.rename(columns={'B01003_001E': 'POPULATION'}, inplace=True)
            df_year['YEAR'] = year
            all_years_data.append(df_year)
    except Exception as e:

        pass

if all_years_data:
    df_historique = pd.concat(all_years_data, ignore_index=True)
    df_historique['POPULATION'] = pd.to_numeric(df_historique['POPULATION'])
    print(f"Jeu de données historique créé : {len(df_historique)} lignes.")

# ==========================
# === QUESTION 8 ===
# ==========================
# Téléchargement, extraction et affichage du Shapefile des États américains

zip_url = "https://www2.census.gov/geo/tiger/GENZ2019/shp/cb_2019_us_state_20m.zip"
zip_filename = "cb_2019_us_state_20m.zip"
extract_dir = "us_states_shp"

print("\nTéléchargement et extraction du shapefile des US...")
try:
    # Téléchargement
    res = requests.get(zip_url)
    with open(zip_filename, 'wb') as file:
        file.write(res.content)

    # Extraction
    with zipfile.ZipFile(zip_filename, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)

    # Chargement avec GeoPandas
    shp_path = os.path.join(extract_dir, "cb_2019_us_state_20m.shp")
    us_states = gpd.read_file(shp_path)


    us_states = us_states[~us_states['STUSPS'].isin(['AK', 'HI', 'PR'])].copy()

    # Affichage
    us_states.plot(figsize=(10, 6), edgecolor='black', color='lightgreen')
    plt.title("Carte des États-Unis (Cartographic Boundary)")
    plt.axis('off')
    plt.show()
except Exception as e:
    print(f"Erreur lors du traitement du shapefile : {e}")

# ==========================
# === QUESTION 9 ===
# ==========================
# Appariement, calcul de la densité et création des cartes

if 'df_2019' in locals() and 'us_states' in locals():
    # Appariement de la carte et du jeu de données 2019 (clé de jointure : NAME)
    us_merged = us_states.merge(df_2019, on='NAME', how='inner')

    # Calcul de l'aire en km2 : Projection en Albers (EPSG:5070)
    us_merged_proj = us_merged.to_crs("EPSG:5070")
    us_merged['area_km2'] = us_merged_proj.geometry.area / 10 ** 6

    # Calcul de la densité
    us_merged['density'] = us_merged['POPULATION'] / us_merged['area_km2']

    # 9.a : Carte choroplèthe de la densité
    fig, ax = plt.subplots(figsize=(12, 6))
    us_merged.plot(column='density', ax=ax, cmap='OrRd', legend=True,
                   legend_kwds={'label': "Densité (habitants / km²)"})
    ax.set_title("Densité de population par État américain (2019)", fontsize=14)
    ax.axis('off')
    plt.show()

    # 9.b : Carte catégorielle
    median_density = us_merged['density'].median()
    us_merged['density_category'] = us_merged['density'].apply(
        lambda x: 'Au-dessus de la médiane' if x >= median_density else 'En dessous de la médiane'
    )


    color_dict = {'Au-dessus de la médiane': 'darkred', 'En dessous de la médiane': 'lightcoral'}

    fig, ax = plt.subplots(figsize=(12, 6))
    for category, color in color_dict.items():
        us_merged[us_merged['density_category'] == category].plot(
            ax=ax, color=color, edgecolor='black', linewidth=0.5
        )

    # Légende manuelle pour la carte catégorielle
    cat_legend = [Patch(facecolor=color_dict[cat], edgecolor='black', label=cat) for cat in color_dict]
    ax.legend(handles=cat_legend, loc='lower right')
    ax.set_title("Densité de la population : Supérieure ou Inférieure à la Médiane", fontsize=14)
    ax.axis('off')
    plt.show()

